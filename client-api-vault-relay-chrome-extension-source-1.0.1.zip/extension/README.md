# Client API Vault Relay Chrome Extension

Client API Vault Relay is a **Manifest V3 Chrome extension** for keeping provider credentials in an encrypted vault inside the user's Chrome profile. The extension only contacts an API provider after the user approves that provider's precise origin at runtime.

## Local testing

Open `chrome://extensions`, enable **Developer mode**, select **Load unpacked**, and choose the `extension/` directory. Create a vault, add a provider entry, and confirm the provider-origin permission when Chrome prompts for it.

## Package for the Chrome Web Store

From the project root, run:

```bash
pnpm run extension:package
```

The resulting ZIP is written to `/home/ubuntu/Downloads/` by default. To use a different output directory, set `CHROME_EXTENSION_DIST` before running the command. Upload the ZIP—not the project folder—to the Chrome Web Store Developer Dashboard.

## Data handling summary

The vault envelope is stored in `chrome.storage.local` and encrypted with a user-created password that is not stored by the extension. API credentials and prompts are sent only to the provider selected by the user. The extension does not include analytics, advertising, remote script loading, or a developer-operated credential relay.
