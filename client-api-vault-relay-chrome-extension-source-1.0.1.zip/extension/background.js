import { sendCompletion } from "./providers.js";

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "CLIENT_VAULT_CHAT") return undefined;

  sendCompletion(message.payload)
    .then(text => sendResponse({ ok: true, text }))
    .catch(error => sendResponse({ ok: false, error: error instanceof Error ? error.message : "Request failed." }));

  return true;
});
